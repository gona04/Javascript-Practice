'use strict';

const userPrefs = {
 city: 'Chicago',
  lat: 41.878113,
 lon: -87.629799,
};

const region = ((city) => {

});

console.log(region(userPrefs.city));