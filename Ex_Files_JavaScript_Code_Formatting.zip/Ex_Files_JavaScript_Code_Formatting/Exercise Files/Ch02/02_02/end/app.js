/*
 * Sasha Vodnik
 * JavaScript Best Practices for Code Formatting
 * LinkedIn Learning
 */

'use strict';

const city = 'Chicago';
console.log(city);