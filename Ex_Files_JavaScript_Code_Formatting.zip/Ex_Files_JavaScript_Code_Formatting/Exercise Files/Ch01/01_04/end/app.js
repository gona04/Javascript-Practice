'use strict';

const city = 'Chicago';
console.log(city);