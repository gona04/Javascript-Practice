/* 
 * Sasha Vodnik
 * JavaScript Best Practices for Code Formatting
 * LinkedIn Learning
 */

'use strict';

// Variables
const city = 'Chicago';
console.log(city);